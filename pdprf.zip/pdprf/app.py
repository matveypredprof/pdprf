from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3

app = Flask(__name__)
app.secret_key = 'my_secret_key'

conn = sqlite3.connect('all.db')
cursor = conn.cursor()

# Создание базы данных и таблиц при запуске
def init_db():
    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT DEFAULT 'student',
            fio TEXT NOT NULL,
            login TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Таблица карт
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            number TEXT NOT NULL,
            owner TEXT NOT NULL,
            amount REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()
    print("✓ База данных создана!")


@app.route('/')
def index():
    return redirect('/entr')


@app.route('/entr', methods=['GET', 'POST'])
def entr():
    if request.method == 'POST':
        return check_user()
    return render_template('entrance.html')


@app.route('/stud')
def stud():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('stud.html')


@app.route('/profstud')
def profstud():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('ProfileStudent.html')


@app.route('/chefprof')
def chefprof():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('index.html')


@app.route('/purch')
def purch():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('purchases.html')


@app.route('/invent')
def invent():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('inventory.html')


@app.route('/order')
def order():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('orders.html')


@app.route('/adminprof')
def adminprof():
    if 'fio' not in session:
        return redirect('/entr')
    return render_template('adminprof.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/entr')


@app.route('/api/entr', methods=['POST'])
def check_user():
    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    # Получаем данные из JSON
    data = request.get_json()
    login = data.get('login')
    password = data.get('password')

    if not login or not password:
        conn.close()
        return jsonify({
            'success': False,
            'message': '❌ Логин и пароль обязательны!'
        }), 400

    cursor.execute('SELECT * FROM users WHERE login = ? AND password = ?', (login, password))
    user = cursor.fetchone()

    conn.close()

    if user:
        session['user_id'] = user[0]
        session['fio'] = user[2]
        session['login'] = user[3]
        session['role'] = user[1]

        role = user[1]

        # print(session.get(fio))

        if role == 'student':
            redirect_url = '/stud'
        elif role == 'cook':
            redirect_url = '/chefprof'
        elif role == 'admin':
            redirect_url = '/adminprof'
        else:
            redirect_url = '/stud'

        return jsonify({
            'success': True,
            'message': '✅ Вход выполнен!',
            'redirect': redirect_url
        }), 200
    else:
        return jsonify({
            'success': False,
            'message': '❌ Неверный логин или пароль!'
        }), 401


# ⭐ ИСПРАВЛЕННЫЙ ЭНДПОИНТ РЕГИСТРАЦИИ
@app.route('/reg', methods=['GET', 'POST'])
def registrat():
    if request.method == 'GET':
        return render_template('registrat (1).html')

    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '❌ Нет данных в запросе'}), 400

        fio = data.get('fio', '').strip()
        login = data.get('login', '').strip()
        password = data.get('password', '').strip()
        role = data.get('role', 'student').strip()

        # Валидация
        if not all([fio, login, password]):
            return jsonify({'success': False, 'message': '❌ Все поля обязательны!'}), 400
        if len(password) < 6:
            return jsonify({'success': False, 'message': '❌ Пароль должен быть не менее 6 символов!'}), 400
        if role not in ['student', 'cook', 'admin']:
            role = 'student'  # Защита от некорректной роли



        # Проверка уникальности логина
        cursor.execute('SELECT id FROM users WHERE login = ?', (login,))
        if cursor.fetchone():
            conn.close()
            return jsonify({'success': False, 'message': '❌ Пользователь с таким логином уже существует!'}), 400

        # Регистрация + получение ID
        cursor.execute('''
            INSERT INTO users (fio, login, password, role)
            VALUES (?, ?, ?, ?)
        ''', (fio, login, password, role))

        user_id = cursor.lastrowid  # Критически важно!
        conn.commit()
        conn.close()

        # 🔐 АВТОМАТИЧЕСКАЯ АВТОРИЗАЦИЯ: сохраняем данные в сессию
        session['user_id'] = user_id
        session['login'] = login
        session['fio'] = fio

        # Определение целевой страницы
        redirect_map = {
            'student': '/stud',
            'cook': '/chefprof',
            'admin': '/adminprof'
        }
        redirect_url = redirect_map.get(role, '/stud')

        return jsonify({
            'success': True,
            'message': f'✅ Регистрация успешна! Добро пожаловать, {fio}!',
            'redirect': redirect_url,
            'role': role
        }), 200

    except Exception as e:
        if 'conn' in locals():
            try:
                conn.close()
            except:
                pass
        print(f"❌ Ошибка регистрации: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': '❌ Критическая ошибка сервера. Обратитесь к администратору.'
        }), 500


@app.route('/api/profstud', methods=['POST'])
def profystud():  # Примечание: опечатка в названии функции сохранена для совместимости
    try:
        # Проверка авторизации
        if 'user_id' not in session or 'fio' not in session:
            return jsonify({
                'success': False,
                'message': '❌ Сессия утеряна. Пожалуйста, войдите снова.'
            }), 401

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '❌ Нет данных'}), 400

        number = data.get('cardNumber', '').strip()
        owner = data.get('cardOwner', '').strip()
        try:
            amount = float(data.get('amount', 0))
        except (TypeError, ValueError):
            return jsonify({'success': False, 'message': '❌ Некорректная сумма!'}), 400

        # Валидация данных
        if not number or not owner or amount <= 0:
            return jsonify({'success': False, 'message': '❌ Заполните все поля корректно!'}), 400
        if len(number) < 4:
            return jsonify({'success': False, 'message': '❌ Номер карты слишком короткий!'}), 400

        # Безопасная работа с БД через контекстный менеджер
        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            # Дополнительная проверка существования пользователя в БД
            cursor.execute('SELECT fio FROM users WHERE id = ?', (session['user_id'],))
            user_check = cursor.fetchone()
            if not user_check:
                session.clear()
                return jsonify({
                    'success': False,
                    'message': '❌ Пользователь не найден. Требуется повторный вход.'
                }), 401

            # Сохранение карты
            cursor.execute('''
                INSERT INTO cards (user_id, number, owner, amount)
                VALUES (?, ?, ?, ?)
            ''', (session['user_id'], number, owner, amount))

            # Получаем актуальное ФИО из сессии (гарантированно существует)
            data = request.get_json()
            dn = data.get('cardNumber', '')
            if dn:
                cfio = session['fio']
                clog = session['login']
                if cfio and clog:
                    return jsonify({
                        'fio': cfio,
                        'login': clog
                    })

        # Формируем ответ с корректным ФИО и маскированным номером
        masked_number = f"{'*' * (len(number) - 4)}{number[-4:]}" if len(number) >= 4 else number

        return jsonify({
            'success': True,
            'message': f'✅ Карта {masked_number} добавлена! Баланс пополнен на {amount:.2f} ₽',
            'cardLast4': number[-4:],
            'amount': amount
        }), 200

    except Exception as e:
        print(f"❌ Критическая ошибка в /api/profstud: {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': '❌ Системная ошибка при обработке карты. Обратитесь к администратору.'
        }), 500

cursor.execute('select * from users')
print(cursor.fetchall())

if __name__ == '__main__':
    init_db()  # Создаём базу данных при запуске
    app.run(debug=True, host='0.0.0.0', port=5000)

